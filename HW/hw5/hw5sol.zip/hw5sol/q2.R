# problem 2
f <- function(x,theta1,theta2){
	x^(-3/2)*exp(-theta1*x-theta2/x+2*sqrt(theta1*theta2)+log(sqrt(2*theta2)))
}

MH.sam <- function(Nsim,a,b,theta1,theta2){
	x <- array(dim=Nsim)
	accept <- array(dim=Nsim)
	# initial
	x[1] <- rgamma(1,shape=a,rate=b)
	for (sim in (2:Nsim)){
		temp <- rgamma(1,shape=a,rate=b)
		r <- f(temp,theta1,theta2)*dgamma(x[sim-1],shape=a,rate=b)/(f(x[sim-1],theta1,theta2)*dgamma(temp,shape=a,rate=b))
		if (runif(1)<min(1,r)){
			x[sim] <- temp
			accept[sim] <- 1
		} else {
			x[sim] <- x[sim-1]
			accept[sim] <- 0
		}
	}
	return(list(x=x,accept=accept))
}

x <- seq(0,10,len=1000)
y <- f(x,1.5,2)
plot(x,y,type="l",main="The plot of f (up to a scaling constant)",xlab="z",ylab="")


library(coda)
set.seed(1234)
a <- 4
b <- 4
Nsim <- 2100
Nburn <- 100
thin <- 2
sam <- MH.sam(Nsim,a,b,1.5,2)
mc.sim <- mcmc(sam$x)
mc.sim2 <- window(mc.sim,start=Nburn+1,thin=thin)

traceplot(mc.sim)
mean(sam$accept[(Nburn+1):Nsim])

plot(mc.sim2)
geweke.diag(mc.sim2)

mean(mc.sim2)
sqrt(var(mc.sim2)/1000)

mean(1/mc.sim2)
sqrt(var(1/mc.sim2)/1000)


