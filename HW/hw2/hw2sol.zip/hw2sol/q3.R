## sampling g1
sample.g1 <- function(n){
	return(-log(runif(n)))
}

## sampling g2
sample.g2 <- function(n){
	return(tan(pi/2*runif(n)))
}

## sampling f
sample.f <- function(n,which.g){
	if (which.g==1){
		ratio <- function(x){1/(1+x^2)}
		sample.g <- sample.g1
	} else if (which.g==2) {
		ratio <- function(x){exp(-x)}
		sample.g <- sample.g2
	}

	out <- array(dim=n)
	ind <- 1
	count <- 1
	while (ind<=n){
		x <- sample.g(1)
		if (runif(1)<=ratio(x)){
			out[ind] <- x
			ind <- ind + 1
		}
		count <- count + 1
	}
	return(list(out=out,accept=n/count))
}

## part a
set.seed(1234)

sim.g1 <- sample.g1(5000)
plot(density(sim.g1,from=0,to=5))

sim.g2 <- sample.g2(5000)
plot(density(sim.g2,from=0,to=5))

sim.f1 <- sample.f(5000,1)
plot(density(sim.f1$out,from=0,to=5))

sim.f2 <- sample.f(5000,2)
plot(density(sim.f2$out,from=0,to=5))

## part b
sim.f1$accept
sim.f2$accept

