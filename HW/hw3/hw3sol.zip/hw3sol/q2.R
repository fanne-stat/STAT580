# question 2
testf <- function(x){sqrt(4+x)/(2+sqrt(x))}
plot(testf,0,10,main="{sqrt(4+x)/(2+sqrt(x))",xlab="x",ylab="value")

# sampling g
sample.g <- function(n,theta){
	u <- runif(n)
	const <- 2*gamma(theta)/(2*gamma(theta) + gamma(theta+1/2))
	out <- rgamma(n,shape=1,scale=theta)*(u<const) + rgamma(n,shape=1,scale=(theta+1/2))*(u>=const)
	return(out)
}

# sampling f
sample.f <- function(n,theta){
	out <- array(dim=n)
	ind <- 1
	count <- 1
	while (ind<=n){
		x <- sample.g(1,theta)
		if (runif(1)<=(sqrt(4+x)/(2+sqrt(x)))){
			out[ind] <- x
			ind <- ind + 1
		}
		count <- count + 1
	}
	return(list(out=out,accept=n/count))
}

set.seed(1234)
theta <- 0.5
g <- sample.f(5000,theta)
hist(g$out,main=paste(c("theta = ",theta),collapse=""),xlab="x")
plot(density(g$out,from=0),main=paste(c("theta = ",theta),collapse=""))
g$accept


set.seed(1234)
theta <- 1
g <- sample.f(5000,theta)
hist(g$out,main=paste(c("theta = ",theta),collapse=""),xlab="x")
plot(density(g$out,from=0),main=paste(c("theta = ",theta),collapse=""))
g$accept

set.seed(1234)
theta <- 5
g <- sample.f(5000,theta)
hist(g$out,main=paste(c("theta = ",theta),collapse=""),xlab="x")
plot(density(g$out,from=0),main=paste(c("theta = ",theta),collapse=""))
g$accept


