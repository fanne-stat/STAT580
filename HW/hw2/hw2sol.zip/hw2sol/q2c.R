# Problem 2c
set.seed(1234)

u <- runif(5000)
sim.x <- 10^u
hist(sim.x,main="Histogram of the 5000 sample",ylab="x")
plot(density(sim.x,from=0,to=10),main="Estimated density of the 5000 sample")
