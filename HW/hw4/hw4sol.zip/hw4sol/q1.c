#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE_BUFFER 3000

void get_dat_dim(FILE *f, int *pn, int *pp);
void dgesv_(int *n, int *nrhs, double *a, int *lda, int *ipiv, double *b, int *ldb, int *info);
void linreg(double *X, double *Y, int n, int p1);

int main(int argc, char *argv[]){
  FILE *f;
  int i, j, k, np, n, p, p1, intercept;
  double *y, *desmat, temp;


  /* usage */
  if (argc!=3){
    printf("Parameters: data intercept\n");
    printf("       data: data file\n");
    printf("  intercept: 1=intercept, 0=no intercept\n");
    exit(1);
  }

  /* link the data */
  if ((f = fopen(argv[1], "r"))==NULL){
    printf("Cannot open data file\n");
    exit(0);
  }

  get_dat_dim(f, &n, &p);

  /* determine number of covariates */
  intercept = (atoi(argv[2])==1) ? 1 : 0;
  p1 = p + intercept;
  if (p1==0){
    printf("p1 is 0!\n");
    exit(0);
  }

  /* read file */
  y = (double *)  malloc(sizeof(double)*n);
  desmat = (double *) malloc(sizeof(double)*n*p1);
  j = 0;
  k = 0;
  np = 0;
  while (fscanf(f, "%lf", &temp)==1){
    j = j % (p+1);
    if (j==0){
      y[k] = temp;
    } else {
      desmat[k * p1 + j - 1 + intercept] = temp;
    }
    j++; np++;
    if (j==(p+1)) k++;
  }
  /* checking */
  if (np!=(n*(p+1))){
    printf("dimension mismatch: number of data != number of rows times number of columns\n");
    exit(0);
  }

  if (intercept){
    for (i=0; i<n; i++) desmat[i*p1] = 1.0;
  }
  fclose(f);

  printf("Sample size and number of predictors are %d and %d respectively.\n", n, p);
  /* run the regression */
  linreg(desmat, y, n, p1);
  
  free(y);
  free(desmat);

  return 0;
}

/* determination of numbers of rows and columns */
void get_dat_dim(FILE *f, int *pn, int *pp){
  int i, nchar, n, p;
  char buf[LINE_BUFFER], buf2[LINE_BUFFER];
  
  /* number of columns */
  fgets(buf, LINE_BUFFER, f);
  i = 0;
  p = -1;
  while(i<(strlen(buf)-1)){
    sscanf(buf+i, "%[^ ]", buf2);
    nchar = strlen(buf2);
    i += nchar+1;
    p++;
  }

  /* number of rows */
  n = 1;
  while (fgets(buf, LINE_BUFFER, f)!=NULL) n++;
  if (fgetc(f)!=EOF){
    printf("Error in determining sample size!\n");
    exit(0);
  }

  *pn = n;
  *pp = p;
  
  /* rewind the data file */
  fseek(f, (long)0, SEEK_SET);
}

void linreg(double *X, double *Y, int n, int p1){

  int i, j, k, n2=1, *ipiv, info;
  double *XtX, *XtY;

  ipiv = (int *) malloc(sizeof(int)*p1);
  XtX = (double *) malloc(sizeof(double)*p1*p1);
  XtY = (double *) malloc(sizeof(double)*p1);

  /* t(X) %*% X */
  for (i=0; i<p1; i++){
    for (j=0; j<p1; j++){
      XtX[i*p1+j] = 0;
      for (k=0; k<n; k++)
        XtX[i*p1+j] += X[k*p1+i] * X[k*p1+j];
    }
  }

  /* t(X) %*% Y */
  for (i=0; i<p1; i++){
    XtY[i] = 0;
    for (j=0; j<n; j++){
      XtY[i] += X[j*p1+i] * Y[j];
    }
  }

  /* XtX is symmetric, no transpose needed before passing to Fortran subrountine */
  dgesv_(&p1, &n2, XtX, &p1, ipiv, XtY, &p1, &info);
  if (info!=0)  printf("failure with error %d\n", info);

  /* print beta */
  printf("The regression coefficients: ");
  for (i=0; i<p1; i++){
    printf("%f ", XtY[i]);
  }
  printf("\n");

  free(ipiv);
  free(XtX);
  free(XtY);
}
