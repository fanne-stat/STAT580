# problem 3
w <- function(x,v){
	v*exp(-x^2/2 + (x-1.5)^2/(2*v^2))*(x>1)*(x<2)
}

## v=0.1
v <- 0.1
n <- 100000
set.seed(1234)
y <- w(rnorm(n,mean=1.5,sd=v),v)
mean(y) # estimate
var(y)/n
sqrt(var(y)/n) #standard error
hist(y,main="nu=0.1")

## v=1
v <- 1
n <- 100000
set.seed(1234)
y <- w(rnorm(n,mean=1.5,sd=v),v)
mean(y) # estimate
var(y)/n
sqrt(var(y)/n) #standard error
hist(y,main="nu=1")

## v=10
v <- 10
n <- 100000
set.seed(1234)
y <- w(rnorm(n,mean=1.5,sd=v),v)
mean(y) # estimate
var(y)/n
sqrt(var(y)/n) #standard error
hist(y,main="nu=10")

#integrate(function(x){1/sqrt(2*pi)*exp(-x^2/2)},lower=1,upper=2)
