# Problem 2
## part a
n <- 100000
set.seed(1234)
x <- rexp(n)
y <- (x^2+5)*x
mean(y) # estimate
var(y)/n
sqrt(var(y)/n) #standard error

## part b
# X ~ N(0, 1/2)  (f(x) = \pi^{-1/2} exp(-x^2) )
# Y ~ U(0,1)
# X, Y are independent

n <- 100000
set.seed(1234)
x <- rnorm(n, mean=0, sd=1/sqrt(2))
y <- runif(n)
z <- sqrt(pi)*cos(x*y)
mean(z) # estimate
var(z)/n
sqrt(var(z)/n) #standard error

## part c

### using exponential(1)
n <- 100000
set.seed(1234)
x <- rexp(n,1)
y <- 3/4*x^4*exp(-x^3/4+x)
mean(y) # estimate
var(y)/n
sqrt(var(y)/n) #standard error

### using gamma(scale=1,shape=5)
n <- 100000
set.seed(1234)
x <- rgamma(n,scale=1/2,shape=5)
y <- gamma(5)*3/4*exp(-x^3/4+2*x)/2^5
mean(y) # estimate
var(y)/n
sqrt(var(y)/n) #standard error

### plot
x <- seq(0,10,len=1000)
y <- 3/4*x^4*exp(-x^3/4)
plot(x,y,type="l")
