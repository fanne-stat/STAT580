#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>

int sum(int *x, int n);

SEXP gibbs(SEXP RNsim, SEXP Rx, SEXP Ra, SEXP Rb){
  int Nsim = asInteger(RNsim), n = length(Rx);
  int *x = INTEGER(Rx), sx=sum(x,n), sr, i, sim;
  double a = asReal(Ra), b = asReal(Rb), pp;
  
  SEXP Rsimlam = PROTECT(allocVector(REALSXP, Nsim));  /* lambda */
  SEXP Rsimp = PROTECT(allocVector(REALSXP, Nsim));    /* p */
  SEXP Rsimr = PROTECT(allocMatrix(INTSXP, n, Nsim)); /* r */
  SEXP Rout;  /* output list*/

  double *simlam = REAL(Rsimlam);
  double *simp = REAL(Rsimp);
  int *simr = INTEGER(Rsimr);

  GetRNGstate();

  /* initialization */
  simp[0] = unif_rand();
  simlam[0] = rgamma(a, 1.0/b); /* b is rate */
  for (i=0; i<n; i++)
    simr[i] = (unif_rand() < simp[0]);


  /* simulation */
  for (sim=1; sim<Nsim; sim++){
    sr = sum(simr + (sim-1)*n, n);
    simlam[sim] = rgamma(a+sx, 1.0/sr);
    simp[sim] = rbeta(1.0+sr, n+1.0-sr);
    for (i=0; i<n; i++){
      pp = simp[sim]*exp(-simlam[sim]) / (simp[sim]*exp(-simlam[sim]) +
          (1.0-simp[sim])*(x[i]==0));
      simr[i + sim*n] = (unif_rand() < pp);
    }
  }
  
  PutRNGstate();

  /* output */
  Rout = PROTECT(allocVector(VECSXP, 3));
  SET_VECTOR_ELT(Rout, 0, Rsimlam);
  SET_VECTOR_ELT(Rout, 1, Rsimp);
  SET_VECTOR_ELT(Rout, 2, Rsimr);

  UNPROTECT(4);
  return Rout;
}


int sum(int *x, int n){
  int out = 0;
  int i;
  for (i=0; i<n; i++)
    out += x[i];
  return out;
}
