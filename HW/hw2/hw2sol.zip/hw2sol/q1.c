#include <stdio.h>
#include <math.h>

#define P0 0.01  /* lower limit of the probability */
#define P1 0.5   /* upper limit of the probability */
#define PLEN 10  /* number of columns */
#define N 5      /* number of experiments */


/* this program does not work for large N */

long prod(int m, int n); 
long combn(int n, int r);
double binom_pmf(int x, int n, double p);


/* main function */
/* print the pmf table of a binomial variable */
int main(){
  int x;
  double step, p;

  step = (P1 - P0) / (double) (PLEN-1); /* step size */

  /* header */
  p = P0;
  printf("x\\p\t");
  while (p <= (P1 + step / 2.0)){
    printf("%5.4f ", p);
    p += step;
  }
  printf("\n\n");

  /* content */
  for (x=0; x<=N; x++){
    p = P0;
    printf("%d\t", x);
    while (p <= (P1 + step / 2.0)){
      printf("%5.4f ", binom_pmf(x, N, p));
      p +=step;
    }
    printf("\n");
  }

  return 0;
}


/* prod */
/* m * (m+1) * ... * n */
long prod(int m, int n){
  long out = 1;
  while (n >= m){
    out *= (m++);
  }
  return out;
}

/* combination */
long combn(int n, int r){
  if (2*r/n){
    r = n - r;
  }
  return prod(n-r+1, n) / prod(1, r);
}


/* binomial pmf */
double binom_pmf(int x, int n, double p){
  return combn(n, x) * pow(p, x) * pow((1 - p), n-x);
}

