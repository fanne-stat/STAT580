# problem 1

## part a
n <- 100
p <- 0.3
lam <- 2
### generate sample
set.seed(1234)
r <- (runif(n)<p)*1
x <- rpois(n,lam)*r


## part c
samp <- function(Nsim,x,a,b){
	n <- length(x)
	sim.lam <- array(dim=Nsim)
	sim.p <- array(dim=Nsim)
	sim.r <- matrix(NA,nr=Nsim,nc=n)
	
	# initial
	sim.p[1] <- runif(1)
	sim.lam[1] <- rgamma(1,shape=a,rate=b)
	sim.r[1,] <- (runif(n)<sim.p[1])*1

	# simulation
	for (sim in 2:Nsim){
		# lambda
		sim.lam[sim] <- rgamma(1,shape=(a+sum(x)),rate=sum(sim.r[sim-1,]))
		sim.p[sim] <- rbeta(1,1+sum(sim.r[sim-1,]),n+1-sum(sim.r[sim-1,]))
		sim.r[sim,] <- (runif(n)<(sim.p[sim]*exp(-sim.lam[sim])/(sim.p[sim]*exp(-sim.lam[sim]) + (1-sim.p[sim])*(x==0))))
	}

	return(list(lam=sim.lam,p=sim.p,r=sim.r))
}

library(coda)
### sample
Nsim <- 1000
Nburn <- 300
a <- 1
b <- 1
Nmcmc <- 5
mc.obj <- mcmc.list()
mc.obj2 <- mcmc.list()
for (i in (1:5)){
	sim <- samp(Nsim,x,a,b)
	mc.sim <- mcmc(cbind(sim$lam,sim$p))
	colnames(mc.sim) <- c("lambda","p")
	mc.obj[[i]] <- mc.sim
	mc.obj2[[i]] <- window(mc.sim,start=Nburn+1)
}
par(mfrow=c(2,1));traceplot(mc.obj)

gelman.diag(mc.obj2,autoburnin=F)
plot(mc.obj2)

comb.mc.obj <- rbind(mc.obj2[[1]],mc.obj2[[2]],mc.obj2[[3]],mc.obj2[[4]],mc.obj2[[5]])
comb.mc.obj <- mcmc(comb.mc.obj)
HPDinterval(comb.mc.obj)
