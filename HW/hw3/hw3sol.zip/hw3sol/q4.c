#include <stdio.h>
#define N 16  /* number of observations */
#define P 2   /* number of predictors */

void dgesvd_(char *jobu, char *jobvt, int *m, int *n, double *a, int *lda, double *s, double *u,
    int *ldu, double *vt, int *ldvt, double *work, int *lwork, int *info);

int main(){
  /* longley dataset from R */
  double X[N][P] =
  {{83,107.608},
  {88.5,108.632},
  {88.2,109.773},
  {89.5,110.929},
  {96.2,112.075},
  {98.1,113.27},
  {99,115.094},
  {100,116.219},
  {101.2,117.388},
  {104.6,118.734},
  {108.4,120.445},
  {110.8,121.95},
  {112.6,123.366},
  {114.2,125.368},
  {115.7,127.852},
  {116.9,130.081}};

  double s[P], Y[N][P], work[5*N], meanj;

  int i, j, m=P, n=N, lwork=5*N, info;
  char jobu='N', jobvt='S';
  
  /* centering */
  for (j=0; j<P; j++){
    /* compute mean */
    meanj = 0;
    for (i=0; i<N; i++)
      meanj += X[i][j];
    meanj /= N;

    /* centering */
    for (i=0; i<N; i++)
      X[i][j] -= meanj;
  }


  /* perform SVD of X^T */
  dgesvd_(&jobu, &jobvt, &m, &n, &(X[0][0]), &m, s, NULL, &m, &(Y[0][0]), &m,
      work, &lwork, &info);
  if (info!=0)  printf("failure with error %d\n", info);
  /* If X=UDV^T, then X^T = VDU^T */
  /* Note that Y (in C) is V */
  
  /* print principal component scores */
  
  printf("The principal component scores: \n");
  for (i=0; i<N; i++){
    for (j=0; j<P; j++){
      printf("%f ", Y[i][j]*s[j]);
    }
    printf("\n");
  }

  return 0;
}
