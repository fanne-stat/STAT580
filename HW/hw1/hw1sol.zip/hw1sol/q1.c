#include <stdio.h>
#define lower 0
#define upper 200
#define nstep 5


int main() {
  double f, c, step, upper2;
  
  f = lower;
  step = (upper - lower) / (nstep - 1.0); /* determine the step */
  upper2 = upper + step / 2.0;
  
  printf("F\tC\n");     /* table header */
  while (f <= upper2) {
    c = 5.0 * (f - 32.0) / 9.0;
    printf("%.1f\t%.1f\n", f, c);
    f = f + step;
  }
  
  return 0;
}
