#include <stdio.h>
#include <time.h>  /* for setting seed */
#define MATHLIB_STANDALONE  /* need to define this before including Rmath.h */
                            /* if we use the Rmath library in a standalone mode */
#include <Rmath.h>

/* question 2 b */

int main() {
  double u, x;
  
  set_seed(time(NULL), 580580); /* set seed */
  u = unif_rand(); /* uniform random variable */
  x = pow(10.0, u);
  printf("%f ", x);
  return 0;
}
