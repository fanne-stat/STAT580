#include<stdio.h>

int main(){
  int c;
  
  c = getchar();
  
  while (c != EOF){
    /* shifting using ASCII table */
    if ((c>='a') && (c<='x')){
      /* a to x */
      putchar(c + 2);
    } else {
      putchar(c);
    }
    
    c = getchar();
  }
  
  return 0;
}
